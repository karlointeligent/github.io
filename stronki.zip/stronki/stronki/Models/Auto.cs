﻿using System;

namespace stronki.Models
{
    public class Auto
    {
        public string Marka { get; set; }
        public string Model { get; set; }
        public Auto(string Marka, string Model)
        {
            this.Marka = Marka;
            this.Model = Model;
        }
    }
}

