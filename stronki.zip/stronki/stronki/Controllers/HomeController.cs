﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using stronki.Models;

namespace stronki.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            List<Auto> os = new List<Auto>();
            os.Add(new Auto("Mercedes", "GT-AMG"));
            os.Add(new Auto("AUDI", "R8"));
            os.Add(new Auto("BMW", "serii 7"));
            os.Add(new Auto("Porsche", "Panamera"));
            os.Add(new Auto("Ford", "Mustrang"));
            string tekst = "";
            for (int i = 0; i < os.Count; i++)
            {
                tekst += os[i].Marka + " " + os[i].Model + "\n";
            }
            ViewBag.Auta = tekst;
            return View();
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Contact()
        {
            ViewData["Message"] = "Your contact page.";

            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
